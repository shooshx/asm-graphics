OpenGL Tutorial #36.

Project Name: Radial Blur & Rendering To A Texture

Project Description: How To Create A Radial Blur Effect

Authors Name:	Else Popelse

Web Site: http://nehe.gamedev.net

COPYRIGHT AND DISCLAIMER: (c)2008 Gamedev.net

       If you plan to put this program on your web page or a cdrom of
       any sort, let me know via email, I'm curious to see where
       it ends up :)

       If you use the code for your own projects please give the author credit,
       or mention his web site somewhere in your program or it's docs.

Contact: nehedev@gmail.com

